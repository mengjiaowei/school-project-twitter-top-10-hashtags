<?php

$PageTitle = "Techno Machinery Sweden AB";

function customPageHeader(){?>
  <!--Arbitrary HTML Tags-->
<?php }

include_once('header.php');

//body contents go here
?>
		
	<div class="mainContent">
		<div class="content">	
				<article class="topcontent">	
					<header>
						<h2>Live Feed</h2>
					</header>
					
					<content>

						<h2> some kind of twitter feed here </h2>
						<br><br><br><br><br><br><br><br>
					</content>
					
				</article>

		</div>

	</div>
	</div>

<?php
	include_once('footer.php');
?>
