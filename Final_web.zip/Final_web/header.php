<!doctype html> <!-- --> 
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" href="css/style.css" type="text/css" /> <!-- This is how you reference the css (design) file --> 
	<link href='http://fonts.googleapis.com/css?family=Indie+Flower' rel='stylesheet' type='text/css'>	
	<link href='http://fonts.googleapis.com/css?family=Codystar' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Shadows+Into+Light+Two' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Handlee' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Chewy' rel='stylesheet' type='text/css'>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- this is for the mobile view--> 

    <title>
    	<?= isset($PageTitle) ? $PageTitle : "Default Title"?>
    </title>

    <!-- Additional tags here -->
    <?php if (function_exists('customPageHeader')){
      customPageHeader();
    }?>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>

    
	<script src="ammap/ammap.js" type="text/javascript"></script>
	<script src="ammap/maps/js/worldLow.js" type="text/javascript"></script>

	<script src="amcharts/amcharts.js" type="text/javascript"></script>
	<script src="amcharts/serial.js" type="text/javascript"></script>
	<script type="text/javascript" src="http://www.amcharts.com/lib/3/themes/light.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js" type="text/javascript"></script>

  </head>

<!-- All the div and class files are the part of the design in the css file--> 
  <body class="body">
  	<div class="header">	
  		<div class="wrap"> 
			<div class="header-top">
		 		<div class="logo">
			 		<h1>Marmalade Group</h1>
			 		<h4>Get the most popular twitter hashtags!</h4>
		 		</div>
	   		</div>
   		</div>
	</div>

  <!-- Navigation -->

<!-- This is the design for the menu -->
   <div class="nav">
      <div class="wrap">
		   <div class="menu">
				<ul>
  					<li><a href="index.php"><span>Home</span></a></li>
					<li>Top10
    					<ul>
      						<li><a href="daily_top10.php"><span>Daily</span></a></li>
      						<li><a href="weekly_top10.php"><span>Weekly</span></a></li>
      						<li><a href="monthly_top10.php"><span>Monthly</span></a></li>
    					</ul>
  					</li>
				   <li><a href="map_of_trends.php"><span>Map of Trends</span></a></li>
				  <!-- <li><a href="live_feed.php"><span>Live Feed</span></a></li>-->
  					<li>Chart
    					<ul>
      						<li><a href="chart.php"><span>Daily</span></a></li>
      						<li><a href="weekly_chart.php"><span>Weekly</span></a></li>
      						<li><a href="monthly_chart.php"><span>Monthly</span></a></li>
    					</ul>
  					</li>
				</ul>
	          </div>
	    	<div class="slider">
	              <!--  <img src="img/gear.jpg" alt="" />-->
	        </div>
	    </div>
   </div>
