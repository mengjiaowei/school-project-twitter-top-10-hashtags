<?php

$PageTitle = "Swedish Tweets";
session_start();

function customPageHeader(){?>
  <!--Arbitrary HTML Tags-->
<?php }

include_once('header.php');
//include_once('php_handler.php');
//show the result from riak without regex
//body contents go here
?>

					<header>
						<h2 style="font-family: 'Handlee', cursive">Top 10 hashtags for this week</h2>
					</header>
					
					<content id="daily_content">
					<br>
<!-- this is the comment -->
					<!-- <form id="myfrom" action="php_handler.php" method="get">					
					<input type="submit"> 					
</form>   	
	
					<script>

					document.getElementById("form").submit();
					</script>
						<?php
							
						//AJAX 
						// Writing into the browser console
			/*		    function reqListener () {
					     // console.log(this.responseText);
					    }

					    var oReq = new XMLHttpRequest(); //New request object
					    oReq.onload = function() {
					        //This is where you handle what to do with the response.
					        //The actual data is found on this.responseText
					        // alert(this.responseText); //Will alert: key
					        alert(this.responseText);
					    };

					    oReq.open("get", "php_handler.php", true);
					    //              ^ Don't block the rest of the execution.
					    //                Don't wait until the request finishes to 
					    //                continue.

						oReq.send();*/
							$input_string =  $_SESSION["value"];
							# use regex: php capture group. So we capture the firs word and the number after it in a {}
							$regex = "/{('\w+'),(\d+)}*/"; 
							# the elements that matched the criteria are put in an double dimensional array
							preg_match_all($regex, $input_string, $matches_out);
						?>

						<script type="text/javascript">
							// after the regex part we store the variables in javascript variables
							var string1 = <?php echo  $matches_out[1][0]; ?>;
							var string2 = <?php echo  $matches_out[1][1]; ?>;
							var string3 = <?php echo  $matches_out[1][2]; ?>;
							var string4 = <?php echo  $matches_out[1][3]; ?>;
							var string5 = <?php echo  $matches_out[1][4]; ?>;
							var string6 = <?php echo  $matches_out[1][5]; ?>;
							var string7 = <?php echo  $matches_out[1][6]; ?>;
							var string8 = <?php echo  $matches_out[1][7]; ?>;
							var string9 = <?php echo  $matches_out[1][8]; ?>;
							var string10 = <?php echo  $matches_out[1][9]; ?>;
								
								// we print out the javascript variables
								document.write(
									"#" + string1 + "<br>" +
									"#" + string2 + "<br>" +
									"#" + string3 + "<br>" +
									"#" + string4 + "<br>" +
									"#" + string5 + "<br>" +
									"#" + string6 + "<br>" +
									"#" + string7 + "<br>" +
									"#" + string8 + "<br>" +
									"#" + string9 + "<br>" +
									"#" + string10 + "<br>" 
								);

						</script>
							
						<br>
						<br>
						<br>
						<br>
						<br>
						<br>
						<br>
						<br>
						<br> -->
					</content>
					
				</article>

		</div>

	</div>

	
<script>
	$(document).ready(
function() {
	$.ajax({ 
	url: "/weekly_handler.php",
	data:{},
	success: function( data) {

var regEx = /{('\w+'),(\d+)}/g;
var firstText = /'(\w+)'/;
var secondText = /(?:,)(\d+)/
var final_data = data.match(regEx);
	for (var index in final_data) {
		var first_value = final_data[index].match(firstText)[1];
		var second_value = final_data[index].match(secondText)[1];
				$("#daily_content").append('<p>#' + first_value + '</p>');
	}
	}
		
			});});
	</script>

	<?php
		include_once('footer.php');
	?>


