<?php

# starting a session here and in charts.php to use a variable created here in charts.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('riak-php-client/src/Basho/Riak/Riak.php');
require_once('riak-php-client/src/Basho/Riak/Bucket.php');
require_once('riak-php-client/src/Basho/Riak/Exception.php');
require_once('riak-php-client/src/Basho/Riak/Link.php');
require_once('riak-php-client/src/Basho/Riak/MapReduce.php');
require_once('riak-php-client/src/Basho/Riak/Object.php');
require_once('riak-php-client/src/Basho/Riak/StringIO.php');
require_once('riak-php-client/src/Basho/Riak/Utils.php');
require_once('riak-php-client/src/Basho/Riak/Link/Phase.php');
require_once('riak-php-client/src/Basho/Riak/MapReduce/Phase.php');

# Connect to Riak
$client = new Basho\Riak\Riak('127.0.0.1', 10018);

# Choose a bucket name
$bucket = $client->bucket('Result');

#$key = $bucket->get('kebab');
#assert($val1 == $key->getData()); #just for the errorchecking

# kebab is a key that we get from riak and we get the binary data, value with that key
$key = $bucket->getBinary('Top10_Week');

$json = json_encode($key);
$term = 'data';

# using the stripper function and feeding with the right variables
stripper($json, $term);

# searching in a json file for the value = data 
# and selecting what is after the semicolon
function stripper($json, $term) {

	if (strpos($json, $term) !== false) { # check if the word exists in the json
		$shord = strpos($json, $term); # select the index of the word
		$rest = substr($json, ($shord + 8), - 3); # -1 refers to (length - 1)
		$_SESSION["value"] = $rest; # this variable will be used in charts.php
	    echo $rest;
	} else {
		 echo "didn't find the value";
	}
}



?>
