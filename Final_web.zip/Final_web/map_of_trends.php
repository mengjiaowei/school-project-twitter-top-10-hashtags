<?php

$PageTitle = "Swedish Tweets";

function customPageHeader(){

?>
  <!--Arbitrary HTML Tags-->
<?php }

include_once('header.php');

//body contents go here
?>
		
	<div class="mainContent">
		<div class="content">	
			<article class="topcontent">	
					<header>
						<h2>History</h2>
					</header>
					
					<content>
					
					<p id="demo"></p>

					<script type="text/javascript">
						// Change the demo tag
						document.write(Date());

						function toCelsius (fahrenheit) {
						    return (5/9) * (fahrenheit - 32);
						}
						var length;
						length = 6;
						document.getElementById("demo").innerHTML = toCelsius(39) + " " + "<br>" + length + " " +  typeof false + "<br>";
					</script>
						
					<div id="mapdiv" style="width: 600px; height: 400px;"></div>
						

						<script type="text/javascript">

                             // add all your code to this method, as this will ensure that page is loaded
							    AmCharts.ready(function() {
							        // create AmMap object
							        var map = new AmCharts.AmMap();
							        // set path to images
							        map.pathToImages = "ammap/images/";

							        /* create data provider object
							         map property is usually the same as the name of the map file.

							         getAreasFromMap indicates that amMap should read all the areas available
							         in the map data and treat them as they are included in your data provider.
							         in case you don't set it to true, all the areas except listed in data
							         provider will be treated as unlisted.
							        */
							        var dataProvider = {
							            map: "worldLow",
							            getAreasFromMap:true                    
							        }; 
							        // pass data provider to the map object
							        map.dataProvider = dataProvider;

							        /* create areas settings
							         * autoZoom set to true means that the map will zoom-in when clicked on the area
							         * selectedColor indicates color of the clicked area.
							         */
							        map.areasSettings = {
							            autoZoom: true,
							            selectedColor: "#CC0000"
							        };

							        // let's say we want a small map to be displayed, so let's create it
							        map.smallMap = new AmCharts.SmallMap();

							        // write the map to container div
							        map.write("mapdiv");
							    });
                        </script>
						
					</content>
					
			</article>

		</div>

	</div>
	</div>

<?php
	include_once('footer.php');
?>
