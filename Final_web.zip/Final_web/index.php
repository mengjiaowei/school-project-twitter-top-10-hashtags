<!-- The structure of the website is that it has three parts: the header.php, the sample file with the body of the document, 
and the footer.php that is what is most below. This structure is great, because you don't need to create the menu in every sample file
and if you change something in the menu or header, you change the header.php file and it is automatically updated in every file that includes
the header.php file. Tha same with the footer. --> 


<?php

$PageTitle = "Swedish Tweets";
session_start();

function customPageHeader() { ?>
  <!--Arbitrary HTML Tags-->
<?php }

include_once('header.php');
//body contents go here
?>

	
					<header>


						<h1>Hashtags </h1>
			
					</header>
					
	<content>					
		<br><br>
		<p>Do you want to know Top10 hashtags from twitter?</p>		
		<p>Go ahead click Daily,Weekly or Monthly in Top10.</p>
		<p>Have Fun! :D</p>
		<br>
		<p id="hey">We are Marmalade!</p>		
						
					</content>
					
				</article>

		</div>

	</div>
	
	

<?php
	include_once('footer.php');
?>

