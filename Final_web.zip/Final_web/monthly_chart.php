<?php

$PageTitle = "Swedish Tweets";
session_start();

function customPageHeader(){?>
  <!--Arbitrary HTML Tags-->
<?php }

include_once('header.php');

//body contents go here
?>
		
	
					<header>
						<h2 style="font-family: 'Handlee', cursive">Top10 hashtag for today</h2>
					</header>
					
					<content>
						
						<div id="chartdiv" style="width: 900px; height: 350px;padding:90px"></div>
				
						<?php
							# get the json string from from php_handler.php class using sessions
							$input_string =  $_SESSION["value"];
							#echo $input_string;

							// regex needs to be between /.../ - php regex capture groups
							# http://regexone.com/cheatsheet

							# use regex: php capture group. So we capture the firs word and the number after it in a {}
							$regex = "/{('\w+'),(\d+)}*/";
							# the elements that matched the criteria are put in an double dimensional arrays
							preg_match_all($regex, $input_string, $matches_out);
							
							echo "<br>";
							
							// $matches_out is now an Array of size equal to N+1, for N 
							    // number of groups you are capturing in your regex, and +1
							    // for the substrings that matched.

								#to get the word and the number of hashes to it
								#echo $matches_out[1][0] . " " . $matches_out[2][0];
								/*
								echo "<br>"; 
							    echo count($matches_out);
							    echo "<br>"; 
							    // how many elements are in array[0]
							    echo count($matches_out[0]);
							    echo "<br>";
							    print_r($matches_out[0]);
							    echo "<br>";
							    echo count($matches_out[1]);
							    echo "<br>";
							    print_r($matches_out[1]);
							    echo "<br>";
							    // how many elements are in array[2]
							    echo count($matches_out[2]);
							    echo "<br>";
							    print_r($matches_out[2]);
								*/
						?>

					<script type="text/javascript">

					// either use ajax or open a php session here and do it that way
/*
						//AJAX 
						// Writing into the browser console
					    function reqListener () {
					     // console.log(this.responseText);
					    }

					    var oReq = new XMLHttpRequest(); //New request object
					    oReq.onload = function() {
					        //This is where you handle what to do with the response.
					        //The actual data is found on this.responseText
					        // alert(this.responseText); //Will alert: key
					        alert(this.responseText);
					    };

					    oReq.open("get", "php_handler.php", true);
					    //              ^ Don't block the rest of the execution.
					    //                Don't wait until the request finishes to 
					    //                continue.

						oReq.send();
*/
						//this is the data we get from riak and what we put in the chart
						// after the regex part we store the variables in javascript variables
					    // put the variables that we get after the regex in the map array
var chartData = [];
console.log($.ajax({ 
	url: "/monthly_handler.php",
	data:{},
	async: false,
	success: function(data) {

var regEx = /{('\w+'),(\d+)}/g;
var firstText = /'(\w+)'/;
var secondText = /(?:,)(\d+)/
var final_data = data.match(regEx);
	for (var index in final_data) {
		var first_value = final_data[index].match(firstText)[1];
		var second_value = final_data[index].match(secondText)[1];
		chartData.push({"word_of_hash": first_value, "number_of_hash": second_value});
	}
	}
		
			}));

							/*
							We can use window.onLoad method to start building chart, but as this is not a 
							good practice, amCharts has it’s own method for this – AmCharts.ready. So all the 
							chart code should be placed within this method:
							*/

							AmCharts.ready(function() {
								// chart code will go here
							});

							/*
							First we will need to create an AmCharts.AmSerialChart object for our chart, set it’s dataProvider 
							and categoryField properties. As you may have guessed from the names, dataProvider is used 
							to specify a data source for the chart and categoryField denotes a field in data objects holding values 
							for the category axis (usually X-axis).
							*/

							var chart = new AmCharts.AmSerialChart();
							chart.dataProvider = chartData;
							chart.categoryField = "word_of_hash";

							/* 
							Next we will need to add a graph to our chart. A chart can have multiple graphs, 
							but we will settle for one in this part. Graphs are represented by AmCharts.AmGraph class. 
							We will need to specify valueField (the name of the field in data provider holding graph item values) 
							and set type field to “column” since we are looking to create a column chart (the default is “line”). 
							Then we just add the graph to the chart.
							*/

							var graph = new AmCharts.AmGraph();
							graph.valueField = "number_of_hash";
							graph.type = "column";
							chart.addGraph(graph);

							//Finally we ask our chart to render itself into our chartdiv by calling it’s write() method:
							chart.write('chartdiv');

						</script>

					</content>
					
				</article>

		</div>

	</div>
</div>

<?php
	include_once('footer.php');
?>
