
<!-- This is how the footer looks like -->

<footer class="mainFooter">

		<div class="left_footer"><p style="font-size: 10px;"> 
		<strong>Marmalade Group</strong><br>
		</p></div>

		
</footer>

</body>
</html>
